#!/usr/bin/env python3

"""
> generate_summary_sheet.py <

Generate an overall summary sheet to ease downstream story-creation.

Ambiguous protein groups are dealt with explicitly--individual proteins are
assigned the same directional change (diff_up / up / down / diff_down) but
also noted to belong to which protein group.
"""
import csv
import math
import re

import natural_sort

all_strains =  ['CC7', 'H2', 'RS']

# read permissible gene IDs: genes that are not isoforms/duplicates of others
valid_genes = []
for line in open('ultimate_universe.txt'):
    if not line: continue    
    valid_genes.append(line.strip())

# read protein data
#   prot_data[gene][sample] = change_direction
prot_data = {}

tsv_reader = csv.reader(open('prot.fold_changes.tsv'), delimiter='\t')
strains = next(tsv_reader)[1:]
for row in tsv_reader:
    if not row: continue
    
    # change of plans: if gene_id contains multiple AIPGENEs chained together,
    # then assign the same protein value to the leftmost valid gene).
    gene_ids = re.findall('AIPGENE\d+', row[0])
    gene_ids = [x for x in gene_ids if x in valid_genes]
    if not gene_ids: continue
    
    log2_tpms = [float(x) if x else 0 for x in row[1:]]
    change_dir = []
    for l in log2_tpms:
        c = ''
        if l < 0:
            c = 'down'
        elif l > 0:
            c = 'up'
        
        if abs(l) > math.log(1.2, 2):
            c = 'diff_' + c
        
        change_dir.append(c)
        
    for g in gene_ids:
        prot_data[g] = {x:y for x, y in zip(strains, change_dir)}

# read tx data
#   tx_data[gene][sample] = change_direction
tx_data = {}
for s in strains:
    tsv_reader = csv.reader(
        open('{}_temp32_vs_temp25_spliced_rt.csv'.format(s.lower())))
    
    header_row = next(tsv_reader)[1:]
    for row in tsv_reader:
        if not row: continue
        
        gene_id = row[0]
        if gene_id not in valid_genes: continue
        
        if gene_id not in tx_data:
            tx_data[gene_id] = {}
        
        qval = row[2]
        beta = row[3]
        
        c = ''
        if qval != 'NA':
            if float(beta) < 0:
                c = 'down'
            elif float(beta) > 0:
                c = 'up'
            
            if float(qval) < 0.05:
                c = 'diff_' + c
        
        tx_data[gene_id][s] = c

all_possible_genes = list(tx_data.keys()) + list(prot_data.keys())
all_possible_genes = natural_sort.natural_sort(set(all_possible_genes))

# print datasheet out
output_header = ['gene_id'] + \
                [x + '_' + y for x in all_strains for y in ['tx', 'prot']]
with open('summary_sheet.tsv', 'w') as f:
    print (*output_header, sep='\t', file=f)
    for g in all_possible_genes:
        output_line = [g]
        for s in all_strains:
            temp = ['', '']
            if g in tx_data:
                if s in tx_data[g]:
                    temp[0] = tx_data[g][s]
            
            if g in prot_data:
                if s in prot_data[g]:
                    temp[1] = prot_data[g][s]
            
            output_line += temp
        
        # only print lines that has at least a value
        if any(output_line[1:]):
            print (*output_line, sep='\t', file=f)
